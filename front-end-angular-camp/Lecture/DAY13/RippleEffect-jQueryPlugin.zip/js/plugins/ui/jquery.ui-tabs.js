(function(exports, $){
	'use strict';



})(this, this.jQuery);