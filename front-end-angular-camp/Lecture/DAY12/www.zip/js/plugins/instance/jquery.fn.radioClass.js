/*! jquery.fn.radioClass.js © yamoo9.net, 2016 */
(function(exports, $){
    'use strict';

    // 1.
    // 플러그인 존재 유무 검증
    $.fn.radioClass = $.fn.radioClass || function(class_name) {
        // 1.
        // 전달인자 유형 유효성 검증
        if ( $.type(class_name) !== 'string' ) {
            $.error('전달받은 클래스 속성 이름은 문자열로 전달해야 합니다.');
        }
    };

})(this, this.jQuery);