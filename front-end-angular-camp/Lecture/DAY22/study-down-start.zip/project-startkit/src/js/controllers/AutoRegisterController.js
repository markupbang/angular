'use strict';
/*! AutoRegisterController.js © yamoo9.net, 2016 */

angular.module('DemoApp')
.controller('AutoRegisterController', ['$scope', '$http',
  function($scope, $http) {

  $scope.formModel = {};
  $scope.onSubmit = function() {};

}]);