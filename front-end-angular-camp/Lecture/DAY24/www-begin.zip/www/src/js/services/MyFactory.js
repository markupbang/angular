/*! MyFactory.js © yamoo9.net, 2016 */
angular.module('PersonListApp')
.factory('MyFactory', [function(){
  return {};
}]);