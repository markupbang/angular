/*! app.js © yamoo9.net, 2015 */
'use strict';

// 모듈
require('angular');
require('angular-route');
require('angular-animate');
require('./controllers');

// AngularJS
var onePieceApp = angular.module('onePieceApp', ['ngRoute', 'onePieceControllers']);