/*! onePieceControllers 모듈 © yamoo9.net, 2015 */
'use strict';

var onePieceControllers = angular.module('onePieceControllers', ['ngAnimate']);

onePieceControllers.controller('ListController', ['$scope', '$http', function($scope, $http) {

	$scope.sorting_member = '';
	$scope.members = null;

	$http({
		'method': 'GET',
		'url': './data/one-piece.json'
	}).then(function(response){
		$scope.members = response.data;
	});

}]);