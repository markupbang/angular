/*! app.js © yamoo9.net, 2015 */
'use strict';

// 모듈
require('angular');
require('angular-route');
require('angular-animate');
require('./controllers');

// AngularJS
var onePieceApp = angular.module('onePieceApp', ['ngRoute', 'onePieceControllers']);

onePieceApp.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

	$locationProvider
		.html5Mode(true);
		// .hashPrefix('!');

	$routeProvider
		.when('/', {
			'templateUrl': 'views/list.html',
			'controller':  'ListController'
		})
		.when('/member/:memberId', {
			'templateUrl': 'views/member.html',
			'controller':  'DetailsController'
		})
		.otherwise({
			'redirectTo': '/'
		});

}]);