/*! onePieceControllers 모듈 © yamoo9.net, 2015 */
'use strict';

var onePieceControllers = angular.module('onePieceControllers', ['ngAnimate']);

/**
 * List Controller
 * @param  {Object}  $scope  AngularJS 스코프 객체
 * @param  {Service} $http   AngularJS 서비스 객체
 */
onePieceControllers
.controller('ListController', ['$scope', '$http', function($scope, $http) {
	// Model Data - Ajax Call
	$http({
		'method': 'GET',
		'url': './data/one-piece.json'
	}).then(function(response){
		$scope.members = response.data;
	});
	// sorting_member 초기화
	$scope.sorting_member = '';
}]);


/**
 * Details Controller
 * @param  {Object}  $scope  AngularJS 스코프 객체
 * @param  {Service} $http   AngularJS 서비스 객체
 */
onePieceControllers
.controller('DetailsController', ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams) {
	$http.get('./data/one-piece.json').success(function(data) {
		$scope.members = data;
		for( var i=0, l=$scope.members.length; i<l; i++ ){
			if ( $scope.members[i].image === $routeParams.memberId ) {
				$scope.memberId = i;
				$scope.prev_memberId = $scope.memberId > 0 ? $scope.memberId - 1 : $scope.members.length - 1;
				$scope.next_memberId = $scope.memberId < $scope.members.length - 1 ? $scope.memberId + 1 : 0;
				break;
			}
		}
	});
}]);