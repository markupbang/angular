'use strict';

var requireDir = require('require-dir');

requireDir('./gulp_tasks/', {'recurse': true});

// require('require-dir')('./gulp_tasks', {'recurse': true});