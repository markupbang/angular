'use strict';

var $ = require('jquery');
var angular = require('angular');

$(function(){
  console.log($().jquery);
});