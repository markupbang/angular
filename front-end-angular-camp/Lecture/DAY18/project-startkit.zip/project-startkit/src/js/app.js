/*! app.js © yamoo9.net, 2016 */
'use strict';
